WITH peak_hours AS(
SELECT DATE(rental_date) AS Dates, HOUR(rental_date) AS Hours, count(rental_date) AS Rentals, ROW_NUMBER() OVER(PARTITION BY DATE(rental_date) ORDER BY count(rental_date) DESC) AS Ranks
FROM rental
GROUP BY DATE(rental_date), HOUR(rental_date)
)
SELECT * FROM peak_hours 
WHERE ranks = 1;

