SELECT Title, count(rental.rental_id) AS Rental_Count  
FROM film 
INNER JOIN inventory 
ON film.film_id = inventory.film_id 
INNER JOIN rental 
ON inventory.inventory_id = rental.inventory_id
GROUP BY title
ORDER BY rental_count DESC
LIMIT 10;