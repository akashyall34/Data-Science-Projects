SELECT monthname(rental_date) AS Month_Name, YEAR(rental_date) AS Rental_Year, count(rental.rental_id) AS Rental_Count
FROM rental
GROUP BY Month_Name, Rental_Year;