SELECT Staff.Staff_Id, Store_Id, First_Name, Last_Name, count(rental.rental_id) AS Rental_Count
FROM staff
INNER JOIN payment
ON staff.staff_id = payment.staff_id
INNER JOIN rental
ON payment.rental_id = rental.rental_id
GROUP BY staff.staff_id;

